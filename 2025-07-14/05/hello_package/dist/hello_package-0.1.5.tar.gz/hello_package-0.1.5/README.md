# hello_package

A simple Python package that prints "Hello, World!" when run.
thats all