def main():
    print("Hello, World!")  # This is the main function that prints a greeting
if __name__ == "__main__":
    main()  # Call the main function when the script is executed directly